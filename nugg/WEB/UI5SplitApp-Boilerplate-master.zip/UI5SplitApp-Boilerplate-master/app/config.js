//UI5 Boilerplate Configuration
jQuery.sap.declare("ui5bp.app.config");

ui5bp.app.config = {

	//Navigation Mode (LaunchpadMode: false -> LeftMenu Navigation)
    LaunchpadMode: true

};